mahasiswa = {"nama": "Jaki", "umur": 18, "negara": "Indonesia"}

import modul2

u_m = modul2.mahasiswa["umur"]
print(u_m)
