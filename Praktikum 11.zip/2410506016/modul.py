def greeting(nama):

    print("Halo, " + nama)


import modul

modul.greeting("Jaki")
