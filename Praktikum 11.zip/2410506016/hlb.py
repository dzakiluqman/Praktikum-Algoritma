import matematika

print("Luas Lingkaran: ", matematika.luas_lingkaran(5))

import matematika

print("Luas Persegi: ", matematika.luas_persegi(5))
