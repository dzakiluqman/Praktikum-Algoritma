import math

print(math.pi)
print(math.sqrt(5))
print(math.sin(8))
print(math.cos(15))
print(math.tan(10))
