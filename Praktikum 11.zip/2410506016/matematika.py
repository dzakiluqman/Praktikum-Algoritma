pi = float(3.14)


def luas_lingkaran(jari_jari):
    return pi * jari_jari**2


def luas_persegi(sisi):
    return sisi**2
